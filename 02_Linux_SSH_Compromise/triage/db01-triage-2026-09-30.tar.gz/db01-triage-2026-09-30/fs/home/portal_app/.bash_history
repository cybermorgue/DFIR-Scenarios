#1754991064
git clone ssh://git@10.20.30.10/srv/git/kb-deploy.git /opt/kb-deploy
#1754991134
cd /opt/kb-deploy
#1754991204
./migrate.sh --check
#1754991274
exit
#1789728163
cd /opt/kb-deploy
#1789728353
git pull
#1789728543
ls migrations/
#1789728733
mysql -u portal_app -p kb_portal < migrations/2026-09-18_huecos_cita.sql
#1789728923
mysql -u portal_app -p kb_portal -e 'SHOW TABLES'
#1789729540
exit
#1790731622
exit
