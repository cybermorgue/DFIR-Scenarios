#1782563490
ls
#1782563585
cd /var/log/mysql
#1782563680
ls -la
#1782563775
mysql -u jnavarro -p -e 'SHOW DATABASES'
#1782563870
exit
