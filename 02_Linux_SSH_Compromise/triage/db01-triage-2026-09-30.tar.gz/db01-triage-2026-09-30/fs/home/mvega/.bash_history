#1788253963
ls -lh /var/backups/mariadb/
#1788254457
free -m
#1788254701
du -sh /var/lib/mysql/*
#1788255213
df -h /var/lib/mysql
#1788256354
exit
#1788341026
ls -lh /var/backups/mariadb/
#1788341348
uptime
#1788341889
du -sh /var/lib/mysql/*
#1788343696
exit
#1788427038
free -m
#1788427405
df -h /var/lib/mysql
#1788427451
systemctl status mariadb --no-pager
#1788427637
uptime
#1788429356
exit
#1788513673
journalctl -u mariadb --since today --no-pager | tail
#1788514254
df -h
#1788514598
du -sh /var/lib/mysql/*
#1788516717
exit
#1788771968
ls -lh /var/backups/mariadb/
#1788772416
free -m
#1788772708
sudo mysql -e "SHOW PROCESSLIST"
#1788772791
du -sh /var/lib/mysql/*
#1788774037
exit
#1788858355
tail -n 50 /var/log/mysql/error.log
#1788858546
df -h
#1788859355
exit
#1788945540
tail -n 50 /var/log/mysql/error.log
#1788945845
sudo mysql -e "SHOW PROCESSLIST"
#1788946419
free -m
#1788946617
ls -lh /var/backups/mariadb/
#1788947958
exit
#1789032112
df -h
#1789032587
df -h /var/lib/mysql
#1789032632
sudo mysql -e "SHOW PROCESSLIST"
#1789034770
exit
#1789119382
uptime
#1789119639
journalctl -u mariadb --since today --no-pager | tail
#1789122108
exit
#1789354290
sudo -i
#1789463423
sudo mysql -e "SHOW PROCESSLIST"
#1789463496
free -m
#1789463531
df -h
#1789463561
ls -lh /var/backups/mariadb/
#1789464386
exit
#1789550997
free -m
#1789551668
df -h
#1789551699
systemctl status mariadb --no-pager
#1789553603
exit
#1789636270
ls -lh /var/backups/mariadb/
#1789636584
uptime
#1789637745
exit
#1789723092
df -h /var/lib/mysql
#1789723322
du -sh /var/lib/mysql/*
#1789723669
ls -lh /var/backups/mariadb/
#1789724151
journalctl -u mariadb --since today --no-pager | tail
#1789726049
exit
#1789982251
ls -lh /var/backups/mariadb/
#1789982566
tail -n 50 /var/log/mysql/error.log
#1789985299
exit
#1790068230
df -h /var/lib/mysql
#1790068387
ls -lh /var/backups/mariadb/
#1790069377
exit
#1790155227
free -m
#1790155353
uptime
#1790156109
exit
#1790241550
df -h /var/lib/mysql
#1790241868
journalctl -u mariadb --since today --no-pager | tail
#1790242151
systemctl status mariadb --no-pager
#1790242422
uptime
#1790242548
exit
#1790328276
journalctl -u mariadb --since today --no-pager | tail
#1790328854
tail -n 50 /var/log/mysql/error.log
#1790330382
exit
#1790586854
systemctl status mariadb --no-pager
#1790587391
df -h
#1790587921
ls -lh /var/backups/mariadb/
#1790588270
tail -n 50 /var/log/mysql/error.log
#1790589489
exit
#1790672802
uptime
#1790673401
sudo mysql -e "SHOW ENGINE INNODB STATUS\G" | head -40
#1790673893
df -h /var/lib/mysql
#1790675489
exit
#1790696204
exit
#1790696228
ls -lh /var/backups/mariadb/
#1790696695
free -m
#1790719411
systemctl status mariadb --no-pager
#1790719450
df -h
#1790719502
sudo mysql -e "SHOW PROCESSLIST"
#1790719660
ls -lh /var/backups/mariadb/
#1790719755
tail -n 30 /var/log/mysql/error.log
#1790720210
uptime
#1790720267
exit
